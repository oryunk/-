"""실시간 시세 → DB 반영."""

from auth_api import get_connection


def _to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def sync_live_price_batch(items):
    """시세 배치를 DB에 반영."""
    if not items:
        return 0

    conn = None
    updated_count = 0
    try:
        conn = get_connection()
        with conn.cursor() as cursor:
            cursor.execute("SHOW COLUMNS FROM stocks LIKE 'current_price'")
            has_current_price = cursor.fetchone() is not None

            for item in items:
                code = str(item.get("code") or "").strip()
                name = str(item.get("name") or code).strip()
                price = _to_int(item.get("price"), default=0)
                volume = _to_int(item.get("volume"), default=0)
                if not code or price <= 0:
                    continue

                if has_current_price:
                    cursor.execute(
                        """
                        INSERT INTO stocks (symbol, name_ko, current_price, created_at, updated_at)
                        VALUES (%s, %s, %s, NOW(), NOW())
                        ON DUPLICATE KEY UPDATE
                            name_ko = VALUES(name_ko),
                            current_price = VALUES(current_price),
                            updated_at = NOW()
                        """,
                        (code, name, price),
                    )
                else:
                    cursor.execute(
                        """
                        INSERT INTO stocks (symbol, name_ko, created_at, updated_at)
                        VALUES (%s, %s, NOW(), NOW())
                        ON DUPLICATE KEY UPDATE
                            name_ko = VALUES(name_ko),
                            updated_at = NOW()
                        """,
                        (code, name),
                    )

                cursor.execute("SELECT stock_id FROM stocks WHERE symbol = %s", (code,))
                stock_row = cursor.fetchone()
                if not stock_row:
                    continue
                stock_id = stock_row["stock_id"]

                cursor.execute(
                    """
                    INSERT INTO stock_price_daily (stock_id, date, close_price, volume, created_at)
                    VALUES (%s, CURDATE(), %s, %s, NOW())
                    ON DUPLICATE KEY UPDATE
                        close_price = VALUES(close_price),
                        volume = VALUES(volume),
                        created_at = NOW()
                    """,
                    (stock_id, price, volume),
                )
                updated_count += 1

        conn.commit()
    except Exception as e:
        if conn:
            conn.rollback()
        print(f"[LIVE_DB_SYNC] 동기화 실패: {e}")
    finally:
        if conn:
            conn.close()

    return updated_count


def fetch_live_snapshot_batch(codes):
    """DB 시세 스냅샷 (표시용)."""
    cleaned = [str(code).strip() for code in (codes or []) if str(code).strip()]
    if not cleaned:
        return {}

    placeholders = ",".join(["%s"] * len(cleaned))
    sql_cp = f"""
        SELECT symbol, name_ko, current_price
        FROM stocks
        WHERE symbol IN ({placeholders})
    """

    def _row_payload(code, name, price):
        return {
            "code": code,
            "name": name or code,
            "price": price,
            "change": 0,
            "rate": 0.0,
            "volume": 0,
            "direction": "flat",
            "stale": True,
            "error": None,
        }

    conn = None
    rows_by_code = {}
    try:
        conn = get_connection()
        with conn.cursor() as cursor:
            cursor.execute("SHOW COLUMNS FROM stocks LIKE 'current_price'")
            has_current_price = cursor.fetchone() is not None

            if has_current_price:
                cursor.execute(sql_cp, tuple(cleaned))
                rows = cursor.fetchall() or []
                for row in rows:
                    code = str(row.get("symbol") or "").strip()
                    price = _to_int(row.get("current_price"), default=0)
                    if not code or price <= 0:
                        continue
                    rows_by_code[code] = _row_payload(code, row.get("name_ko"), price)

            still = [c for c in cleaned if c not in rows_by_code]
            if not still:
                return rows_by_code

            for code in still:
                cursor.execute(
                    """
                    SELECT s.symbol, s.name_ko, sp.close_price
                    FROM stocks s
                    INNER JOIN stock_price_daily sp ON sp.stock_id = s.stock_id
                    WHERE s.symbol = %s
                    ORDER BY sp.date DESC
                    LIMIT 1
                    """,
                    (code,),
                )
                r = cursor.fetchone()
                if not r:
                    continue
                price = _to_int(r.get("close_price"), default=0)
                if price <= 0:
                    continue
                sym = str(r.get("symbol") or code).strip()
                rows_by_code[sym] = _row_payload(sym, r.get("name_ko"), price)
    except Exception as e:
        print(f"[LIVE_DB_SNAPSHOT] 조회 실패: {e}")
    finally:
        if conn:
            conn.close()

    return rows_by_code
